## Démarrer un nouveau projet.

1. Forkez le repo
1. Renommez-le puis clonez-le sur votre ordinateur